@extends('layouts.app')

@section('content')
<div class="container">
<div class="row justify-content-center">
<img src="{{ asset('images/laravel.png') }}" height="350px" alt="laravel">
</div>
    <div class="row justify-content-center" style="margin-top: -80px; ">
        <div class="col-md-8">
            <div class="card" style="box-shadow: 0px 5px 5px #ddd;">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('Welcome to the Club, ') }}{{ Auth::user()->name }} !
                    <div class="mt-4 row justify-content-center">
                    <a class="btn btn-success" href="{{ route('product') }}">Goto Products</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
